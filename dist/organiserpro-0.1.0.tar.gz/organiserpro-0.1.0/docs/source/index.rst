.. OrganiserPro documentation master file, created by
   sphinx-quickstart on Sun Jun 29 09:22:00 2025.

Welcome to OrganiserPro's documentation!
=======================================

.. toctree::
   :maxdepth: 2
   :caption: Contents:

   installation
   usage
   api
   contributing
   changelog

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
